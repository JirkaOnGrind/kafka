<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class MCCmsLegacy
{
    public static function fetch($db, $table, $nbRecord, $offset, $limit)
    {
        $table = trim($table);
        if (!self::isLegacy()) {
            return false;
        }
        $shopData = self::fetchShop($db, $table, $nbRecord, $offset, $limit);
        if ($shopData !== false) {
            return $shopData;
        }
        if (!$db->tableExist($table)) {
            return false;
        }
        $schema = $db->getSchema($table);
        if (!in_array($table, array('cms_lang', 'cms_category_lang')) || isset($schema['id_shop'])) {
            return false;
        }

        return self::fetchLang($db, $table, $nbRecord, $offset, $limit);
    }

    private static function fetchShop($db, $table, $nbRecord, $offset, $limit)
    {
        $map = array(
            'cms_shop' => array('cms', 'id_cms'),
            'cms_category_shop' => array('cms_category', 'id_cms_category'),
        );
        if (!isset($map[$table]) || $db->tableExist($table) || !$db->tableExist($map[$table][0])) {
            return false;
        }
        $source = $map[$table][0];
        $id = $map[$table][1];
        $shops = self::shops($db);
        if ($nbRecord) {
            $count = (int)Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . bqSQL($source) . '`');
            return array('nb' => $count * count($shops));
        }
        if (!count($shops)) {
            return array();
        }
        $page = self::page($offset, $limit, count($shops));
        $query = 'SELECT `' . bqSQL($id) . '` FROM `' . _DB_PREFIX_ . bqSQL($source) . '` ORDER BY `' . bqSQL($id) . '` ASC';
        if ($page['limit'] > 0) {
            $query .= ' LIMIT ' . (int)$page['offset'] . ', ' . (int)$page['limit'];
        }
        $rows = Db::getInstance()->executeS($query);

        return self::expand($rows, $shops, $page['skip'], $limit, $id);
    }

    private static function fetchLang($db, $table, $nbRecord, $offset, $limit)
    {
        $id = $table === 'cms_lang' ? 'id_cms' : 'id_cms_category';
        $shops = self::shops($db);
        if ($nbRecord) {
            $count = (int)Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . bqSQL($table) . '`');
            return array('nb' => $count * count($shops));
        }
        if (!count($shops)) {
            return array();
        }
        $page = self::page($offset, $limit, count($shops));
        $query = '
            SELECT a.*, l.iso_code
            FROM `' . _DB_PREFIX_ . bqSQL($table) . '` a
            LEFT JOIN `' . _DB_PREFIX_ . 'lang` l ON a.id_lang = l.id_lang
            ORDER BY a.`' . bqSQL($id) . '` ASC, a.`id_lang` ASC';
        if ($page['limit'] > 0) {
            $query .= ' LIMIT ' . (int)$page['offset'] . ', ' . (int)$page['limit'];
        }
        $rows = Db::getInstance()->executeS($query);

        return self::expand($rows, $shops, $page['skip'], $limit);
    }

    private static function shops($db)
    {
        $shops = array();
        foreach ($db->getMultiShops() as $idShop) {
            if ((int)$idShop > 0) {
                $shops[(int)$idShop] = (int)$idShop;
            }
        }
        if (!count($shops) && $db->tableExist('shop')) {
            $rows = Db::getInstance()->executeS('SELECT `id_shop` FROM `' . _DB_PREFIX_ . 'shop` ORDER BY `id_shop` ASC');
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    if (isset($row['id_shop']) && (int)$row['id_shop'] > 0) {
                        $shops[(int)$row['id_shop']] = (int)$row['id_shop'];
                    }
                }
            }
        }
        if (!count($shops)) {
            $idShop = (int)Configuration::get('PS_SHOP_DEFAULT');
            $shops[$idShop > 0 ? $idShop : 1] = $idShop > 0 ? $idShop : 1;
        }

        return array_values($shops);
    }

    private static function page($offset, $limit, $shopCount)
    {
        $offset = (int)$offset;
        $limit = (int)$limit;
        $skip = $shopCount > 0 ? $offset % $shopCount : 0;

        return array(
            'offset' => $shopCount > 0 ? (int)floor($offset / $shopCount) : 0,
            'limit' => $limit > 0 && $shopCount > 0 ? (int)ceil(($skip + $limit) / $shopCount) : 0,
            'skip' => $skip,
        );
    }

    private static function expand($rows, $shops, $skip, $limit, $id = null)
    {
        $data = array();
        if (!is_array($rows)) {
            return $data;
        }
        foreach ($rows as $row) {
            if ($id !== null && (!is_array($row) || !isset($row[$id]) || $row[$id] === '' || $row[$id] === null)) {
                continue;
            }
            foreach ($shops as $idShop) {
                if ($skip > 0) {
                    --$skip;
                    continue;
                }
                $item = $id !== null ? array($id => (int)$row[$id]) : $row;
                $item['id_shop'] = (int)$idShop;
                $data[] = $item;
                if ($limit > 0 && count($data) >= $limit) {
                    return $data;
                }
            }
        }

        return $data;
    }

    private static function isLegacy()
    {
        return version_compare(_PS_VERSION_, '1.6.0.12', '<');
    }
}
