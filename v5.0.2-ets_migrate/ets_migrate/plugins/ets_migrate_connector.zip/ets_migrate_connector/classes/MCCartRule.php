<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class MCCartRule
{
    private static $single_shop;

    public static function skipFilter($db, $table)
    {
        return trim($table) === 'cart_rule' && self::singleShop($db);
    }

    public static function needsRows($db)
    {
        return self::singleShop($db)
            && count($db->getMultiShops()) > 0
            && $db->tableExist('cart_rule')
            && $db->tableExist('cart_rule_shop')
            && $db->columnExist('cart_rule', 'shop_restriction');
    }

    public static function countRows($db)
    {
        $id_shop = self::shopId($db);
        if ($id_shop <= 0) {
            return 0;
        }

        return (int)Db::getInstance()->getValue('
            SELECT COUNT(*)
            FROM `' . _DB_PREFIX_ . 'cart_rule` cr
            LEFT JOIN `' . _DB_PREFIX_ . 'cart_rule_shop` crs ON (crs.`id_cart_rule` = cr.`id_cart_rule` AND crs.`id_shop` = ' . (int)$id_shop . ')
            WHERE cr.`shop_restriction` = 1
                AND crs.`id_cart_rule` IS NULL
        ');
    }

    public static function addRows($db, $data, $offset, $limit)
    {
        if (!is_array($data)) {
            $data = array();
        }

        $id_shop = self::shopId($db);
        if ($id_shop <= 0) {
            return $data;
        }

        $limit = (int)$limit;
        $offset = (int)$offset;
        if ($limit > 0 && count($data) >= $limit) {
            return $data;
        }

        $real_count = self::realRows($db);
        $missing_offset = $offset > $real_count ? $offset - $real_count : 0;
        $missing_limit = $limit > 0 ? $limit - count($data) : 0;
        $sql = '
            SELECT cr.`id_cart_rule`, ' . (int)$id_shop . ' AS `id_shop`
            FROM `' . _DB_PREFIX_ . 'cart_rule` cr
            LEFT JOIN `' . _DB_PREFIX_ . 'cart_rule_shop` crs ON (crs.`id_cart_rule` = cr.`id_cart_rule` AND crs.`id_shop` = ' . (int)$id_shop . ')
            WHERE cr.`shop_restriction` = 1
                AND crs.`id_cart_rule` IS NULL
            ORDER BY cr.`id_cart_rule` ASC';

        if ($missing_limit > 0) {
            $sql .= ' LIMIT ' . (int)$missing_offset . ', ' . (int)$missing_limit;
        }

        $rows = Db::getInstance()->executeS($sql);
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $data[] = $row;
            }
        }

        return $data;
    }

    private static function singleShop($db)
    {
        if (self::$single_shop !== null) {
            return self::$single_shop;
        }
        if (!$db->tableExist('shop')) {
            self::$single_shop = true;
            return self::$single_shop;
        }

        self::$single_shop = (int)Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'shop`') <= 1;
        return self::$single_shop;
    }

    private static function shopId($db)
    {
        $shops = $db->getMultiShops();
        if (isset($shops[0]) && (int)$shops[0] > 0) {
            return (int)$shops[0];
        }

        $id_shop = (int)Configuration::get('PS_SHOP_DEFAULT');
        if ($id_shop > 0) {
            return $id_shop;
        }

        return (int)Db::getInstance()->getValue('SELECT `id_shop` FROM `' . _DB_PREFIX_ . 'shop` ORDER BY `id_shop` ASC');
    }

    private static function realRows($db)
    {
        $id_shop = self::shopId($db);
        if ($id_shop <= 0) {
            return 0;
        }

        return (int)Db::getInstance()->getValue('
            SELECT COUNT(*)
            FROM `' . _DB_PREFIX_ . 'cart_rule_shop`
            WHERE `id_shop` = ' . (int)$id_shop
        );
    }
}
