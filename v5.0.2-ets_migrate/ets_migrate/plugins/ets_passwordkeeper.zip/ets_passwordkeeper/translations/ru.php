<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_9879a22790c154d2e21994f9b87f3c47'] = 'Хранитель паролей PrestaShop';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_1519a9a8f56188e8780e4668a906388a'] = 'Сохраняйте старые пароли при переносе данных между сайтами PrestaShop с помощью модуля переноса';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_923cc3fd014742fbc2a3dd76f2a7d8ca'] = 'Требуется _COOKIE_KEY_ исходного сайта';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_c888438d14855d7d96a2724ee9c306bd'] = 'настройки обновлены';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Параметр';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_97e6c933fc6cd2aa1da4a437bb9ea3f7'] = '_COOKIE_KEY_ исходного веб-сайта Prestashop';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_e93ae3213eb3580d882435939808b54b'] = '_COOKIE_KEY_ предоставляется, когда вы завершаете миграцию с помощью модуля миграции. Он также доступен в файле настроек (settings.inc.php) исходного сайта.';
$_MODULE['<{ets_passwordkeeper}prestashop>ets_passwordkeeper_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранять';
$_MODULE['<{ets_passwordkeeper}prestashop>form_fa535ffb25e1fd20341652f9be21e06e'] = 'Конфигурация';
$_MODULE['<{ets_passwordkeeper}prestashop>form_f25b7a4db1d87afa1d07b8c2355acef1'] = '_COOKIE_KEY_ Исходный веб-сайт Prestashop.';
$_MODULE['<{ets_passwordkeeper}prestashop>form_b17f3f4dcf653a5776792498a9b44d6a'] = 'Обновить настройки';
